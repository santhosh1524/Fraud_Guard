import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface TransactionData {
  amount: number;
  userId: string;
  location: string;
  deviceType: string;
  transactionType: string;
  merchantCategory: string;
  ipAddress?: string;
}

interface PredictionResult {
  probability: number;
  riskLevel: "low" | "medium" | "high";
  confidence: number;
  factors: string[];
  anomalyScore: number;
  recommendation: "approve" | "review" | "block";
}

export const useFraudPrediction = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<PredictionResult | null>(null);
  const { toast } = useToast();

  const predict = async (transaction: TransactionData) => {
    setIsLoading(true);
    setResult(null);

    try {
      const { data, error } = await supabase.functions.invoke("fraud-predict", {
        body: { transaction },
      });

      if (error) {
        throw error;
      }

      if (!data.success) {
        throw new Error(data.error || "Prediction failed");
      }

      setResult(data.analysis);
      return data.analysis;
    } catch (error) {
      const err = error as Error & { status?: number };
      
      if (err.status === 429) {
        toast({
          title: "Rate Limited",
          description: "Too many requests. Please try again in a moment.",
          variant: "destructive",
        });
      } else if (err.status === 402) {
        toast({
          title: "Credits Required",
          description: "Please add credits to your workspace to continue.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Prediction Failed",
          description: err.message || "Failed to analyze transaction",
          variant: "destructive",
        });
      }
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const reset = () => {
    setResult(null);
    setIsLoading(false);
  };

  return {
    predict,
    isLoading,
    result,
    reset,
  };
};
